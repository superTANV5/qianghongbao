package com.codeboy.qianghongbao;

import android.content.Context;

/**
 * <p>Created 16/2/5 下午7:11.</p>
 * <p><a href="mailto:codeboy2013@gmail.com">Email:codeboy2013@gmail.com</a></p>
 * <p><a href="http://www.happycodeboy.com">LeonLee Blog</a></p>
 *
 * @author LeonLee
 */
public final class UmengConfig {

    private UmengConfig() {

    }

    public static boolean isEnableWechat(Context context) {
        return true;
    }
}
